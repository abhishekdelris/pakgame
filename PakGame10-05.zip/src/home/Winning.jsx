import React from 'react'
import userImage1 from '../assets/image/Ellipse-1.png'
import userImage2 from '../assets/image/Ellipse-2.png'
import userImage3 from '../assets/image/Ellipse-3.png'
import userImage4 from '../assets/image/Ellipse-4.png'
import userImage5 from '../assets/image/Ellipse-5.png'
import winintImage1 from '../assets/image/Winning-1.png'
import winintImage2 from '../assets/image/Winning-2.png'
import winintImage3 from '../assets/image/Winning-3.png'

const Winning = () => {
  return (
    <>
       {/* Winning Start */}
        <div className="row">
            <div className="col-12">
                <div className="lottery-heading">
                <h3>Winning information</h3>
                </div>
            </div>
            <div className="col-12">
                <div className="winning-card">
                <div className="winning-inner">
                    <img src={userImage1} alt />
                    <h5>Mem***FIM</h5>
                </div>
                <div className="winning-bottom">
                    <div className="winning-image">
                    <img src={winintImage1} alt />
                    </div>
                    <div>
                    <h3>Recieve Rs170.00</h3>   
                    <h4>Winning amount</h4>
                    </div>
                </div>
                </div>
            </div>
            <div className="col-12">
                <div className="winning-card">
                <div className="winning-inner">
                    <img src={userImage2} alt />
                    <h5>Mem***MUV</h5>
                </div>
                <div className="winning-bottom">
                    <div className="winning-image">
                    <img src={winintImage1} alt />
                    </div>
                    <div>
                    <h3>Recieve Rs17.00</h3>   
                    <h4>Winning amount</h4>
                    </div>
                </div>
                </div>
            </div>
            <div className="col-12">
                <div className="winning-card">
                <div className="winning-inner">
                    <img src={userImage3} alt />
                    <h5>Mem***VNW</h5>
                </div>
                <div className="winning-bottom">
                    <div className="winning-image">
                    <img src={winintImage2} alt />
                    </div>
                    <div>
                    <h3>Recieve Rs30.00</h3>   
                    <h4>Winning amount</h4>
                    </div>
                </div>
                </div>
            </div>
            <div className="col-12">
                <div className="winning-card">
                <div className="winning-inner">
                    <img src={userImage4} alt />
                    <h5>Mem***NIS</h5>
                </div>
                <div className="winning-bottom">
                    <div className="winning-image">
                    <img src={winintImage2} alt />
                    </div>
                    <div>
                    <h3>Recieve Rs130.00</h3>   
                    <h4>Winning amount</h4>
                    </div>
                </div>
                </div>
            </div>
            <div className="col-12">
                <div className="winning-card">
                <div className="winning-inner">
                    <img src={userImage5} alt />
                    <h5>Mem***DYB</h5>
                </div>
                <div className="winning-bottom">
                    <div className="winning-image">
                    <img src={winintImage3} alt />
                    </div>
                    <div>
                    <h3>Recieve Rs500.00</h3>   
                    <h4>Winning amount</h4>
                    </div>
                </div>
                </div>
            </div>
        </div>
        {/* Winning Start */}

    </>
  )
}

export default Winning
