import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from "react-router-dom";
import Cookies from 'js-cookie'; 
import { Modal, Button } from 'react-bootstrap';
import Banner from './Banner';
import Attention from './Attention';
import Categories from './Categories';
import Lottery from './Lottery';
import Winning from './Winning';
import WinningList from './WinningList';
// import Footer from '../common/Footer'

const Home = () => {
  const [showModal, setShowModal] = useState(false);  // State to handle modal visibility
  const navigate = useNavigate();

  // Use useEffect to trigger the modal after a delay when the page loads
  useEffect(() => {
    const userId = Cookies.get('user_id');
    const modalShown = Cookies.get('modal_shown'); // Track if modal has already been shown

    if (userId && !modalShown) {
      // Delay the modal display by 5 seconds
      const timer = setTimeout(() => {
        setShowModal(true);
        // Set a cookie to track that the modal has been shown
        Cookies.set('modal_shown', 'true', { expires: 1 }); // Cookie expires in 1 day
      }, 1000); // 5000 ms = 5 seconds

      // Cleanup function to clear the timeout if the component unmounts
      return () => clearTimeout(timer);
    }
  }, []);

  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-lg-4 col-md-6 col-12 mx-auto bg-color">
            <Banner />
            <Attention />
            <Categories />
            <Lottery />
            <Winning />
            <WinningList />
            {/* <Footer /> */}
          </div>
        </div>
      </div>

       {/* Modal for displaying the policy content */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered className='notification-modal'>
        <Modal.Header>
          <Modal.Title>Important Policy Update</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <h2>Welcome Back PAKGAMES Member</h2>
          <h4 className='text-success text-center'>Dear members before withdrawing please confirm that your wallet has been verified, and the lD card and account</h4>
          <h4 className='text-success text-center'>number used for verification are true and valid, otherwise your withdrawal will not be successful!</h4>
          <h4 className='text-success text-center'>Follow Us On PakGames Official Telegram Channel &gt;&gt; <a href="" target="_blank">CLICK HERE</a> &lt;&lt; for latest announcements and event information</h4>
          <h2>Dear Members starting 15th of July the recharge bonus will go back to 2% for your every recharge.</h2>
          <h2>BUT DON"T WORRY!  you can now use the QR Code recharge Bank Card channel to get  4% bonus for your EVERY RECHARGE!</h2>
          <img src="https://ossimg.pakgamelucky.com/pakgames/editor/editor_20240823142022b4ss.png" className='img-fluid' alt="" />
          <h2> VIP GOLD</h2>
          <p>VIP GOLD REWARD for the month of 1 March To 30 April. Get a chance to win</p>
          <p>Click the link below for more information :</p>
          <p>WE HAVE MANY BONUS FOR YOU TO CLAIM</p>
          <ul>
            <li>1. First Deposit Bonus : After register and bind E-wallet account to claim the bonus</li>
            <li>2. Attendance Bonus : Do deposit till 7 day straight to claim the bonus </li>
            <li>3. Gifts Code : Use the code the agent give to receive a bonus </li>
            <li>4. Activity Award : Reach till the requirement and claim the bonus awaits you </li>
            <li>5. Invitation Bonus : Invite individuals to deposit and play, you will receive the bonus </li>
            <li>6. Betting Rebate : Every betting you do will get commission </li>
            <li>7. Super Jackpot : Play on slot game and when you have big win can get the bonus </li>
            <li>8. VIP Bonus: This bonus you can claim it monthly and every level VIP you increase  </li>
          </ul>
          <p>Join us and become part of our agent to get the amazing benefit. the best aspect of joining our agent, if more you invite and the higher level of your downlines,the greater the bonuses you may receive, resulting the more downlines.</p>
        </Modal.Body>
        <Modal.Footer>
          <button className="view-all-btn" onClick={() => setShowModal(false)}>
            Confirm 
          </button>
        </Modal.Footer>
      </Modal>
    </>
  )
}

export default Home
