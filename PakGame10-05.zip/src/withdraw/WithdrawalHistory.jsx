import React from "react";
import depositeIcon from '../assets/image/deposite/deposite-icon-3.png'
import noData from '../assets/image/deposite/no-data.png'

const WithdrawalHistory = () => {
  return (
    <>
      <div className="row">
        <div className="col-12">
          <div className="deposit-history-card">
            <h5>
              <img src={depositeIcon} alt />
              Withdrawal history
            </h5>
            <div className="text-center">
              <img
                src={noData}
                className="img-fluid"
                alt
              /> 
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default WithdrawalHistory;
