// import React from 'react'
import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Cookies from 'js-cookie';
import accountUser from '../assets/image/account-user.png'
import userTag from '../assets/image/user-tag.png'
import rsImg from '../assets/image/rs-img.png'
import userIcon1 from '../assets/image/user-icon/user-icon-1.png'
import userIcon2 from '../assets/image/user-icon/user-icon-2.png'
import userIcon3 from '../assets/image/user-icon/user-icon-3.png'
import userIcon4 from '../assets/image/user-icon/user-icon-4.png'

const AccountHead = () => {
    const baseURLAPI = import.meta.env.VITE_BASE_URL_API;
    const navigate = useNavigate();
    const [profile, setProfile] = useState([]);
    const [loading, setLoading] = useState(true);
    // const userId = sessionStorage.getItem('user_id');
    const userId = Cookies.get('user_id');
    useEffect(() => {
    // Retrieve the user_id from session storage
    // const userId = sessionStorage.getItem('user_id');
    const userId = Cookies.get('user_id');

    if (userId) {
        fetch(`${baseURLAPI}users/get_profile?user_id=${userId}`)
        .then(response => response.json())
        .then(data => {
            // console.log(data);
            // return false;
            setProfile(data);
            setLoading(false);
        })
        .catch(error => console.error('Error fetching profile:', error));
    } else {
        console.error('Please Login First.');
        navigate('/login');
        setLoading(false);
    }
    }, []);

    if (loading) {
    return <div>Loading...</div>;
    }

    const handleSendReferral = () => {
        const myHeaders = new Headers();
        myHeaders.append("Cookie", "ci_session=85c9g64c108kdala2ocdtihvb4eak7uo");
    
        const formdata = new FormData();
        formdata.append("user_id", userId);
    
        const requestOptions = {
          method: "POST",
          headers: myHeaders,
          body: formdata,
          redirect: "follow"
        };
    
        fetch("https://delristech-projects.in/pak_game/index.php/api/users/send_referral_link", requestOptions)
          .then((response) => response.json()) // Assuming API returns JSON
          .then((result) => {
            console.log(result); // Log the result to see the response
            if (result && result.referralLink) {
              // If the response contains a URL, redirect
              window.location.href = result.referralLink || "http://localhost:5173/register?referral=WJPKEX"   //|| result.referralLink;
            } else {
              console.error("No URL found in the response.");
            }
          })
          .catch((error) => console.error("Error:", error));
      };
    

// console.log(profile);
// return false;
  return (
    <>
        <div className="row account-user-top">
            <div className="account-user-heading">
                <img src={profile.data.profile_image} className="user-profile" alt />
                <div>
                <h6>{profile.data.username} <img src={userTag} alt="icon" /></h6>
                <div className="uid">
                    <p>UID | {profile.data.referal_code}</p>   
                    <button onClick={handleSendReferral}>   
                    <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" width={17} height={15}><path d="M19 22H5c-1.654 0-3-1.346-3-3V8h2v11c0 .552.449 1 1 1h14c.552 0 1-.448 1-1v-2h2v2C22 20.654 20.654 22 19 22zM16.707 11.707L15.293 10.293 18.586 7 15.293 3.707 16.707 2.293 21.414 7z"/><path d="M8,18H6v-1c0-6.065,4.935-11,11-11h3v2h-3c-4.963,0-9,4.037-9,9V18z"/></svg>                
                    {/* <svg width={17} height={15} viewBox="0 0 17 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M6.58333 4.04314V3.186C6.58333 2.37787 6.58333 1.97382 6.85182 1.72276C7.12032 1.47171 7.55243 1.47171 8.41667 1.47171H13C13.8642 1.47171 14.2963 1.47171 14.5648 1.72276C14.8333 1.97382 14.8333 2.37787 14.8333 3.186V7.47171C14.8333 8.27982 14.8333 8.68388 14.5648 8.93494C14.2963 9.186 13.8642 9.186 13 9.186H12.0833M3.83333 13.4717H8.41667C9.2809 13.4717 9.71302 13.4717 9.98151 13.2207C10.25 12.9696 10.25 12.5655 10.25 11.7574V7.47171C10.25 6.6636 10.25 6.25954 9.98151 6.00848C9.71302 5.75742 9.2809 5.75742 8.41667 5.75742H3.83333C2.96909 5.75742 2.53697 5.75742 2.26848 6.00848C2 6.25954 2 6.6636 2 7.47171V11.7574C2 12.5655 2 12.9696 2.26848 13.2207C2.53697 13.4717 2.96909 13.4717 3.83333 13.4717Z" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg> */}
                    </button>
                </div>
                <div className="last-login">
                    {/* <p>Last login:2024-04-16  15:45:45</p> */}
                </div>
                </div>
            </div>
            <div className="col-12">
                <div className="account-user-card">
                <p>Total balance</p>
                <h5>Rs{profile.data.total_amount} <img src={rsImg} alt /></h5>
                <div className="account-user-card-icon">
                    <div>
                        <Link to={'/wallet'}>
                        <img src={userIcon1} alt />
                        <p>Wallet</p>
                        </Link>
                    </div>
                    <div>
                        <Link to={'/deposit'}>
                            <img src={userIcon2} alt />
                            <p>Deposit</p>
                        </Link>
                    </div>
                    <div>
                        <Link to={'/withdraw'} >
                            <img src={userIcon3} alt />
                            <p>Withdraw</p>
                        </Link>
                    </div>
                    <div>
                    <img src={userIcon4} alt />
                    <p>VIP</p>
                    </div>
                </div>
                </div>
            </div>
        </div>

    </>
  )
}

export default AccountHead
