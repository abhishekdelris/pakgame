// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import './App.css';
import Header from './common/Header';
import Home from './home/Home';
import Game from './home/Game';
import ActivityHome from './activity/ActivityHome';
import Footer from './common/Footer';
import WalletHome from './wallet/WalletHome';
import AccountHome from './account/AccountHome';
import DepositHome from './deposit/DepositHome';
import WithdrawHome from './withdraw/WithdrawHome';
import AgencyHome from './agency/AgencyHome';
import Login from './login/Login';
import Register from './login/Register';
import Forgot from './login/ForgotPassword';
import GameListing from './game/GameListing';
import CategoriesList from './game/CategoriesList';
import Sendotp from './login/Sendotp';
import UpdateProfile from './account/UpdateProfile';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import FirstRecharge from './activity/FirstRecharge';
import ActivityDetail from './activity/ActivityDetail';
import DailyTasks from './activity/DailyTasks';
import Rebate from './activity/Rebate';
import SuperJackpot from './activity/SuperJackpot';
import RedeemGift from './activity/RedeemGift';
import DailySignIn from './activity/DailySignIn';
import Vip from './account/Vip';
import GameStats from './account/GameStats';
import Feedback from 'react-bootstrap/esm/Feedback';

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Route for Home page with Header and Footer */}
        <Route
          path="/"
          element={
            <>
              <Header />
              <Home />
              <Footer />
            </>
          }
        />
        {/* Route for ActivityHome page with Footer only */}
        <Route
          path="activity"
          element={
            <>
              <ActivityHome />
              <Footer />
            </>
          }
        />
        {/* Route for WalletHome page with Footer only */}
        <Route
          path="/wallet"
          element={
            <>
              <WalletHome />
              <Footer />
            </>
          } 
        />
         <Route
          path="/updateProfile"
          element={
            <>
              <UpdateProfile />
              <Footer />
            </>
          }
          />
        {/* Route for AccountHome page with Footer only */}
        <Route
          path="/account"
          element={
            <>
              <AccountHome />
              <Footer />
            </>
          }
        />
        {/* Route for Account VIP page with Footer only */}
        <Route
          path="/vip"
          element={
            <>
              <Vip />
              <Footer />
            </>
          }
        />
        {/* Route for Account Game Stats page with  */}
        <Route
          path="/gameStats"
          element={
            <>
              <Header />
              <GameStats />
              <Footer />
            </>
          }
        />
        {/* Route for Account Feedback page with y */}
        <Route
          path="/feedback"
          element={
            <>
              <Header />
              <Feedback />
              <Footer />
            </>
          }
        />
        {/* Route for DepositHome page with Footer only */}
        <Route
          path="/deposit"
          element={
            <>
              <DepositHome />
              <Footer />
            </>
          }
        />
        {/* Route for WithdrawHome page with Footer only */}
        <Route
          path="/withdraw"
          element={
            <>
              <WithdrawHome />
              <Footer />
            </>
          }
        />
        {/* Route for AgencyHome page with Footer only */}
        <Route
          path="/agency"
          element={
            <>
              <AgencyHome />
              <Footer />
            </>
          }
        />
        {/* route for login page  */}
        <Route
          path="/login"
          element={
            <>
              <Login />
              {/* <Footer /> */}
            </>
          }
        />
        {/* route for register page  */}
        <Route
          path="register"
          element={
            <>
              <Register />
              {/* <Footer /> */}
            </>
          }
        />
        {/* route for register page  */}
        <Route
          path="/game"
          element={
            <>
              <Header />
              <Game />
              <Footer />
              {/* <Footer /> */}
            </>
          }
        />

        {/* route for register page  */}
        <Route
          path="/forgot"
          element={
            <>
              <Forgot />
              {/* <Footer /> */}
            </>
          }
        />
        {/* route for Game Listing page  */}
        <Route
          path="/GameListing/:id"
          element={
            <>
              <Header />
              <GameListing />
              <Footer />
            </>
          }
        />
        <Route
          path="/GameListing"
          element={
            <>
              <Header />
              <GameListing />
              <Footer />
            </>
          }
        />
        {/* route for Category Listing page  */}
        <Route
          path="/CategoriesListing"
          element={
            <>
              <Header />
              <CategoriesList />
              <Footer />
            </>
          }
        />
        {/* route for Send OTP page  */}
        <Route
          path="/Sendotp"
          element={
            <>
              <Header />
              <Sendotp />
              <Footer />
            </>
          }
        />
        {/* route for Activity First Recharge page  */}
        <Route
          path="/firstrecharge"
          element={
            <>
              <Header />
              <FirstRecharge />
              <Footer />
            </>
          }
        />
        {/* route for Activity detail page  */}
        <Route
          path="/activitydetail"
          element={
            <>
              <Header />
              <ActivityDetail />
              <Footer />
            </>
          }
        />
        {/* route for Activity Daily Tasks page  */}
        <Route
          path="/dailytasks"
          element={
            <>
              <Header />
              <DailyTasks />
              <Footer />
            </>
          }
        />
        {/* route for Activity Rebate Tasks page  */}
        <Route
          path="/rebate"
          element={
            <>
              <Header />
              <Rebate />
              <Footer />
            </>
          }
        />
        {/* route for Activity Super Jackpot Tasks page  */}
        <Route
          path="/superJackpot"
          element={
            <>
              <Header />
              <SuperJackpot />
              <Footer />
            </>
          }
        />
        {/* route for Activity Redeem Gift Tasks page  */}
        <Route
          path="/redeemGift"
          element={
            <>
              <Header />
              <RedeemGift />
              <Footer />
            </>
          }
        />
        {/* route for Activity Daily Sign In Tasks page  */}
        <Route
          path="/dailySignIn"
          element={
            <>
              <Header />
              <DailySignIn />
              <Footer />
            </>
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
