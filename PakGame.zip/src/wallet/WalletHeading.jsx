import React from "react";
import walletIcon from '../assets/image/wallet-icon.png'

const WalletHeading = () => {
  return (
    <>
      <div className="col-12">
        <div className="wallet-heading-inner">
          <h5>WALLET</h5>
          <img src={walletIcon} alt />
          <h6>Rs0.00</h6>
          <p>Total balance</p>
        </div>
      </div>
    </>
  );
};

export default WalletHeading;
