import React from 'react'
import './ActivityDetail.css'

const ActivityDetail = () => {
  return (
    <>
        <div className="container">
            <div className="row">
                <div className="col-lg-4 col-md-6 col-12 mx-auto bg-color px-0">
                    <div className="activity-detail-top">
                        <img src="https://delristech-projects.in/pak_game/upload/banners/666044d5aaa90_10day.png" alt="" />
                    </div>
                </div>
            </div>
            <div className="row">
                <div className="col-lg-4 col-md-6 col-12 mx-auto bg-color h-100vh">
                    <div className="activity-detail-content">
                        <h6 className='text-center'>SUPER CASHBACK BONUS 30%</h6>
                        <img src="https://ossimg.pakgamelucky.com/pakgames/editor/editor_2024090217015773ci.png" className='img-fluid' alt="" />
                        <p className='text-center'>Please click on the link below to contact one of our bonus representatives</p>
                    </div>
                </div>
            </div>
        </div>
    </>
  )
}

export default ActivityDetail
