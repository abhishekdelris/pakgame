import React from "react";
import './DailySignIn.css'

const DailySignIn = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-lg-4 col-md-6 col-12 mx-auto bg-color px-0">
            <div className="redeem-gift-header">
              <img
                src="https://pakgames.net/assets/png/headerBg-c5504bca.png"
                className="img-fluid"
                alt=""
              />
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-lg-4 col-md-6 col-12 mx-auto bg-color h-100vh pt-3"></div>
        </div>
      </div>
    </>
  );
};

export default DailySignIn;
