import React, { useEffect, useState } from 'react';
import './SettingsCenter.css'; // Import your CSS for styles
import { Link, useNavigate, useLocation } from "react-router-dom";
import Cookies from 'js-cookie';
import depositIcon from '../assets/image/deposite-icon.png';
import AccountHead from '../account/AccountHead';
import AccountSafe from '../account/AccountSafe';
import UserService from '../account/UserService';
import userTag from '../assets/image/user-tag.png'
import rsImg from '../assets/image/rs-img.png'
import userIcon1 from '../assets/image/user-icon/user-icon-1.png'
import userIcon2 from '../assets/image/user-icon/user-icon-2.png'
import userIcon3 from '../assets/image/user-icon/user-icon-3.png'
import userIcon4 from '../assets/image/user-icon/user-icon-4.png'

const SettingsCenter = () => {
  const navigate = useNavigate();
  const baseURLAPI = import.meta.env.VITE_BASE_URL_API;
  const handleBackClick = () => {
    navigate(-1);
    // alert("hello")
  };
  const [profile, setProfile] = useState([]);
  const [loading, setLoading] = useState(true);
  // const userId = sessionStorage.getItem('user_id');
  const userId = Cookies.get('user_id');
  useEffect(() => {
  // Retrieve the user_id from session storage

  // const userId = sessionStorage.getItem('user_id');
  const userId = Cookies.get('user_id');

  if (userId) {
      fetch(`${baseURLAPI}users/get_profile?user_id=${userId}`)
      .then(response => response.json())
      .then(data => {
          // console.log(data);
          // return false;
          setProfile(data);
          setLoading(false);
      })
      .catch(error => console.error('Error fetching profile:', error));
  } else {
      console.error('Please Login First.');
      navigate('/login');
      setLoading(false);
  }
  }, []);

  if (loading) {
  return <div>Loading...</div>;
  }

  const handleSendReferral = () => {
      const myHeaders = new Headers();
      myHeaders.append("Cookie", "ci_session=85c9g64c108kdala2ocdtihvb4eak7uo");
  
      const formdata = new FormData();
      formdata.append("user_id", userId);
  
      const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: formdata,
        redirect: "follow"
      };
  
      fetch("https://delristech-projects.in/pak_game/index.php/api/users/send_referral_link", requestOptions)
        .then((response) => response.json()) // Assuming API returns JSON
        .then((result) => {
          console.log(result); // Log the result to see the response
          if (result && result.referralLink) {
            // If the response contains a URL, redirect
            window.location.href = result.referralLink || "http://localhost:5173/register?referral=WJPKEX"   //|| result.referralLink;
          } else {
            console.error("No URL found in the response.");
          }
        })
        .catch((error) => console.error("Error:", error));
    };

    const copyUID = () => {
      navigator.clipboard.writeText(profile.data.userId);
      alert("UID copied!");
    };

  return (
   
     
    <div className="settings-center"> 
     <div className="container">
    <div className="row">
      <div className="col-lg-4 col-md-6 col-12 mx-auto agency-bg-color">
      <div className="row account-user-top">
           
            <div className="col-12">
                {/* <div className="account-user-card"> */}
                {/* <div className="account-user-heading">
                <img src={profile.data.profile_image} className="user-profile" alt />
                <p>Nickname</p>
             </div> */}
             <div className="userInfo__container-setting-center">
      
      {/* Header Section with Avatar and Change Avatar Button */}
      <div className="userInfo__container-setting-center-header">
        <div className="userInfo__container-content__avatar">
          <img src={profile.data.profile_image} alt="Avatar" />
        </div>
        <div className="userInfo__container-setting-center-header-edit">
          <span>Change avatar</span>
          <i className="van-icon van-icon-arrow" style={{ color: '#888' }}></i>
        </div>
      </div>

      {/* Nickname Section */}
      <div className="userInfo__container-setting-center-content ar-1px-b">
        <h5>Nickname</h5>
        <div>
          <span>{profile.data.username}</span>
          <i className="van-icon van-icon-arrow" style={{ color: '#888' }}></i>
        </div>
      </div>

      {/* UID Section */}
      <div className="userInfo__container-setting-center-content">
        <h5>UID</h5>
        <div>
          <span>{profile.data.userId}</span>
          <svg onClick={copyUID} className="svg-icon icon-copy">
            <use xlinkHref="#icon-copy" />
          </svg>
        </div>
      </div>
      
    </div>
                </div>
            {/* </div> */}
        </div>
        <div className="security-info">
        <h2>Security information</h2>

        <div className="security-item">
          <div className="item-left">
            <img src="https://via.placeholder.com/20" alt="icon" />
            <p>Login password</p>
          </div>
          <button className="edit-button">Edit</button>
        </div>

        <div className="security-item">
          <div className="item-left">
            <img src="https://via.placeholder.com/20" alt="icon" />
            <p>Bind mailbox</p>
          </div>
          <button className="edit-button">to bind</button>
        </div>

        <div className="security-item">
          <div className="item-left">
            <img src="https://via.placeholder.com/20" alt="icon" />
            <p>Google Verification</p>
          </div>
          <button className="edit-button">Unopened</button>
        </div>

        <div className="security-item">
          <div className="item-left">
            <img src="https://via.placeholder.com/20" alt="icon" />
            <p>Updated version</p>
          </div>
          <p className="version">1.0.9</p>
        </div>
      </div>
        {/* <AccountSafe />
        <UserService /> */}
      </div>
    </div>
    
  </div>

   

     
    </div>
   
  
  );
};

export default SettingsCenter;
