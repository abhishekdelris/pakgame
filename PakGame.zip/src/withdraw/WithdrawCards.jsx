import React from "react";
import withdraw1 from '../assets/image/deposite/Withdraw-1.png'
import withdraw2 from '../assets/image/deposite/Withdraw-2.png'
import addIcon from '../assets/image/deposite/add-icon.png'

const WithdrawCards = () => {
  return (
    <>
      <div className="row">
        <div className="col-12">
          <div className="deposite-card-inner">
            <ul>
              <li>
                <img src={withdraw1} alt />
                <p>E-Wallet</p>
              </li>
              <li>
                <img src={withdraw2} alt />
                <p>USDT</p>
              </li>
            </ul>
            <div className="deposite-card-add">
              <img src={addIcon} alt />
              <p>Add</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default WithdrawCards;
